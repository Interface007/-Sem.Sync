Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Net.Sockets
Imports System.Net
Imports System.Xml
Imports System.Io
Namespace Internal
    Friend Class StringHelper
        Public Function MD5Hex(ByVal stringValue As String)
            Dim md5 As New System.Security.Cryptography.MD5CryptoServiceProvider
            Dim Data As Byte()
            Dim Result As Byte()
            Dim Res As String = ""
            Dim tmp As String = ""

            Data = Encoding.ASCII.GetBytes(stringValue)
            Result = md5.ComputeHash(Data)

            For i As Integer = 0 To Result.Length - 1
                tmp = Hex(Result(i))
                If Len(tmp) = 1 Then
                    tmp = "0" & tmp
                End If
                Res += tmp
            Next

            Return Res
        End Function
    End Class
    Friend Class NetworkHelper
        Public Function SOAPAction(ByVal callClass As Object, ByVal action As String, ByVal urn As String, ByVal submitValues As Hashtable, ByVal returnValues As Hashtable, Optional ByVal authString As String = "")
            Dim InternalStringFunctions As New Internal.StringHelper

            ' Define SOAP Request
            Dim sRequest As String = ""
            sRequest += "<?xml version=""1.0""?>" + vbCrLf
            sRequest += "<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/"" s:encodingStyle=""http://schemas.xmlsoap.org/soap/encoding/"">" + vbCrLf
            sRequest += "<s:Body>" + vbCrLf
            sRequest += "<u:" + action + " xmlns:u=""" + urn + """>" + vbCrLf

            If submitValues.Count > 0 Then
                For Each submitItem As DictionaryEntry In submitValues
                    sRequest += "<" + callClass.prefixSOAP + submitItem.Key + ">"
                    sRequest += submitItem.Value.ToString
                    sRequest += "</" + callClass.prefixSOAP + submitItem.Key + ">"
                Next
                sRequest += vbCrLf
            End If
            sRequest += "</u:" + action + ">" + vbCrLf
            sRequest += "</s:Body>" + vbCrLf
            sRequest += "</s:Envelope>" + vbCrLf

            ' Define SOAP Header
            Dim sHeader As String = ""
            sHeader += "POST " + callClass.controlURL + " HTTP/1.1" + vbCrLf
            sHeader += "HOST: " + callClass.host + ":" + callClass.port + vbCrLf
            sHeader += "CONTENT-LENGTH: " + Len(sRequest).ToString + vbCrLf
            sHeader += "CONTENT-TYPE: text/xml; charset=""utf-8""" + vbCrLf
            sHeader += "SOAPACTION: """ + urn + "#" + action + """" + vbCrLf
            sHeader += "USER-AGENT: AVM UPnP/1.0 Client 1.0" + vbCrLf

            MsgBox(sHeader + vbCrLf + sRequest)

            ' If authentication string is given, the last process failed because login is needed - to the stuff here
            Dim sHeaderAuth As String = ""
            If authString.Length > 0 Then
                ' Extract neccessary informations
                Dim authenticationArray As Array = authString.Split(",")
                Dim authenticationConfig As New Hashtable

                For nIndex As Integer = 0 To authenticationArray.Length - 1
                    Dim authInfo As Array = authenticationArray(nIndex).ToString.Split("=")
                    Dim authKey = authInfo(0).ToString.ToLower
                    Dim authValue = authInfo(1).ToString.Replace("""", "")
                    authValue.ToString.Replace(vbCrLf, "")
                    Select Case authKey
                        Case "nonce", "algorithm", "qop"
                            authenticationConfig.Add(authKey, authValue)
                    End Select
                Next

                Dim RandomClass As New Random()
                Dim RandomNumber As Integer = RandomClass.Next

                authenticationConfig.Add("cnonce", InternalStringFunctions.MD5Hex(RandomNumber).ToString.Substring(0, 16))
                authenticationConfig.Add("nc", "00000001")
                authenticationConfig.Add("digest realm", "HTTPS Access")

                Dim MD5 As New System.Security.Cryptography.MD5CryptoServiceProvider()

                Dim authStringPart1 As String = InternalStringFunctions.MD5Hex(callClass.HTTPusername + ":" + authenticationConfig("digest realm") + ":" + callClass.HTTPpassword).ToString.ToLower
                Dim authStringPart2 As String = InternalStringFunctions.MD5Hex("POST:" + callClass.controlURL).ToString.ToLower
                Dim authStringFinal As String = InternalStringFunctions.MD5Hex( _
                    authStringPart1 + ":" + _
                    authenticationConfig("nonce") + ":" + _
                    authenticationConfig("nc") + ":" + _
                    authenticationConfig("cnonce") + ":" + _
                    authenticationConfig("qop") + ":" + _
                    authStringPart2).ToString.ToLower

                sHeaderAuth += "Authorization: "
                sHeaderAuth += "Digest username=""" + callClass.HTTPusername + ""","
                sHeaderAuth += "realm=""HTTPS Access"","
                sHeaderAuth += "nonce=""" + authenticationConfig("nonce") + ""","
                sHeaderAuth += "uri=""" + callClass.controlURL + ""","
                sHeaderAuth += "cnonce=""" + authenticationConfig("cnonce") + ""","
                sHeaderAuth += "nc=" + authenticationConfig("nc") + ","
                sHeaderAuth += "algorithm=" + authenticationConfig("algorithm") + ","
                sHeaderAuth += "response=""" + authStringFinal + ""","
                sHeaderAuth += "qop=""" + authenticationConfig("qop") + """"
                sHeaderAuth += vbCrLf
            End If

            Dim deviceRequest As Byte()
            deviceRequest = System.Text.Encoding.ASCII.GetBytes(sHeader + sHeaderAuth + vbCrLf + sRequest)

            Dim clientSocketTCP As New System.Net.Sockets.TcpClient
            clientSocketTCP.Connect(callClass.host, callClass.port)

            Dim remoteStream As NetworkStream = clientSocketTCP.GetStream()
            Dim responseXML As String = ""

            If remoteStream.CanWrite And remoteStream.CanRead Then
                Dim responseBytesRead(clientSocketTCP.ReceiveBufferSize) As Byte
                Dim responseString As String
                Dim responseArray As Array
                Dim responseLength As Integer

                remoteStream.Write(deviceRequest, 0, deviceRequest.Length)
                remoteStream.Flush()
                remoteStream.Read(responseBytesRead, 0, CInt(clientSocketTCP.ReceiveBufferSize))

                responseString = Encoding.ASCII.GetString(responseBytesRead)
                responseArray = Split(responseString, vbCrLf)
                MsgBox(responseString)
                If responseString.Contains("HTTP/1.1 401 Unauthorized") And authString.Length = 0 Then
                    ' Declare string for authentication information
                    Dim authenticationString As String = ""

                    For nIndex As Integer = 0 To responseArray.Length - 1
                        If responseArray(nIndex).ToString.ToLower.Contains("www-authenticate:") Then
                            authenticationString = responseArray(nIndex).ToString.Substring(Len("www-authenticate:"))
                        End If
                    Next
                    responseXML = Me.SOAPAction(callClass, action, urn, submitValues, returnValues, authenticationString)
                Else
                    For nIndex As Integer = 0 To responseArray.Length - 1
                        If responseArray(nIndex).ToString.ToLower.Contains("content-length:") Then
                            responseLength = responseArray(nIndex).ToString.Substring(Len("content-length:"))
                        End If

                        If Len(responseArray(nIndex)) = 0 Then
                            responseXML = responseArray(nIndex + 1)
                        End If
                    Next
                End If
            Else
                Dim remoteException As New ArgumentException
                If Not remoteStream.CanRead Then
                    Throw New InvalidOperationException("Can't read from remote device " + callClass.host + ":" + callClass.port)
                End If
                If Not remoteStream.CanWrite Then
                    Throw New InvalidOperationException("Can't write to remote device " + callClass.host + ":" + callClass.port)
                End If
                clientSocketTCP.Close()
            End If
            MsgBox(responseXML)
            Return (responseXML)
        End Function
        Public Function GetXMLKey(ByVal callClass As Object, ByVal XMLCode As String, ByVal urnSchema As String, ByVal command As String, ByVal Key As String, Optional ByVal errorCode As Boolean = False)

            ' Define new XmlDocument Object
            Dim xmlSource As New System.Xml.XmlDocument()

            ' Remove unwanted signs (NULL for example...)
            XMLCode = XMLCode.Substring(0, XMLCode.LastIndexOf("s:Envelope") + Len("s:Envelope") + 1)

            ' Load given xml code string as xml structure
            xmlSource.LoadXml(XMLCode)

            ' Define NamespaceManager for direct access of keys/values
            Dim nsmgr As XmlNamespaceManager = New XmlNamespaceManager(xmlSource.NameTable)

            ' Add given urn schema
            nsmgr.AddNamespace("u", urnSchema)

            ' Get given command and subkey
            Dim xn As XmlNodeList
            If errorCode = False Then
                xn = xmlSource.DocumentElement.SelectNodes("//u:" + command + "Response/New" + Key, nsmgr)
            Else
                xn = xmlSource.DocumentElement.SelectNodes("//u:" + command + "/u:" + Key, nsmgr)
            End If

            ' Return result or nothing
            If xn.Count > 0 Then
                Return xn.Item(0).InnerText.ToString
            Else
                Return Nothing
            End If
        End Function
        Public Function GetXMLContent(ByVal callClass As Object, ByVal command As String, ByVal urnSchema As String, ByVal submitTable As Hashtable, ByVal returnTable As Hashtable)

            Dim XMLCode As String = ""
            Dim XMLResult As String = ""
            Dim XMLErrorCode As String = ""
            Dim newReturnTable As New Hashtable

            If returnTable.Count > 0 Then
                XMLCode = Me.SOAPAction(callClass, command, urnSchema, submitTable, returnTable)
                XMLErrorCode = GetXMLKey(callClass, XMLCode, "urn:schemas-upnp-org:control-1-0", "UPnPError", "errorCode", True)
                returnTable.Add("errorCode", XMLErrorCode)
                For Each returnItem As DictionaryEntry In returnTable
                    XMLResult = GetXMLKey(callClass, XMLCode, urnSchema, command, returnItem.Key)
                    returnItem.Value = XMLResult
                    newReturnTable.Add(returnItem.Key, XMLResult)
                Next
                returnTable = newReturnTable
            Else
                XMLCode = Me.SOAPAction(callClass, command, urnSchema, submitTable, returnTable)
                XMLErrorCode = GetXMLKey(callClass, XMLCode, "urn:schemas-upnp-org:control-1-0", "UPnPError", "errorCode", True)
                returnTable.Add("errorCode", XMLErrorCode)
            End If
            Return returnTable
        End Function

    End Class
End Namespace
