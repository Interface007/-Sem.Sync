Imports FritzBoxNET.Internal

Namespace Service
    Public Class Foncontrol
        ' Where the service are controlled
        Public controlURL As String = "/upnp/control/foncontrol"

        ' Where events can be monitored
        Public eventURL As String = "/upnp/control/foncontrol"

        ' Where the scpd file can be found
        Public SCPDURL As String = "/foncontrol-scpd.xml"

        ' The destination hostname (IP)
        Public host As String = ""

        ' The destination port
        Public port As String = "49000"

        ' Username, is used for authentication (should not changed)
        Public HTTPusername As String = "fbox"

        ' Password, is used for authentication (THAT should be changed...)
        Public HTTPpassword As String = ""

        ' Needed urn schema
        Public urnSchema As String = "urn:schemas-any-com:service:foncontrol:1"

        ' Needed prefix for SOAP submit
        Public prefixSOAP As String = ""

        ' Which minimum major version is required
        Const specVersionMajorMin = 1

        ' Which minimum minor version is required
        Const specVersionMinorMin = 0

        ' Which maximum major version is required
        Const specVersionMajorMax = 1

        ' Which maximum minor version is required
        Const specVersionMinorMax = 0

        ' We need some internal functions...
        Private InternalStringFunctions As New Internal.StringHelper
        Private InternalNetworkFunctions As New Internal.NetworkHelper
        Public Function GetUserList()
            Dim submitTable As New Hashtable

            ' Function returns: ServerVersion, ProtocolVersion
            Dim returnTable As New Hashtable
            returnTable.Add("UserList", "")
            returnTable = InternalNetworkFunctions.GetXMLContent(Me, "GetUserList", Me.urnSchema, submitTable, returnTable)

            Return returnTable
        End Function
        Public Function GetCallLists(ByVal User As Integer)
            Dim submitTable As New Hashtable
            submitTable.Add("User", User)

            ' Function returns: ServerVersion, ProtocolVersion
            Dim returnTable As New Hashtable
            returnTable.Add("CallListsURL", "")
            returnTable = InternalNetworkFunctions.GetXMLContent(Me, "GetCallLists", Me.urnSchema, submitTable, returnTable)

            Return returnTable
        End Function
    End Class
End Namespace
