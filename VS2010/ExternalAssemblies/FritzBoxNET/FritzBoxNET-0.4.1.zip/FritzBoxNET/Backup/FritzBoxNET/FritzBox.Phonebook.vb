Imports FritzBoxNET.Internal

Namespace Service
    Public Class Phonebook
        ' Where the service are controlled
        Public controlURL As String = "/upnp/control/phonebook"

        ' Where events can be monitored
        Public eventURL As String = "/upnp/control/phonebook"

        ' Where the scpd file can be found
        Public SCPDURL As String = "/phonebook-scpd.xml"

        ' The destination hostname (IP)
        Public host As String = ""

        ' The destination port
        Public port As String = "49000"

        ' Username, is used for authentication (should not changed)
        Public HTTPusername As String = "fbox"

        ' Password, is used for authentication (THAT should be changed...)
        Public HTTPpassword As String = ""

        ' Needed urn schema
        Public urnSchema As String = ""

        ' Which minimum major version is required
        Const specVersionMajorMin = 1

        ' Which minimum minor version is required
        Const specVersionMinorMin = 0

        ' Which maximum major version is required
        Const specVersionMajorMax = 1

        ' Which maximum minor version is required
        Const specVersionMinorMax = 0

        ' We need some internal functions...
        Private InternalStringFunctions As New Internal.StringHelper
        Private InternalNetworkFunctions As New Internal.NetworkHelper
    End Class
End Namespace
